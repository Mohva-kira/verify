import React from 'react'
import { useNavigate } from 'react-router-dom'

const LogOut = () => {
    const navigate = useNavigate()
    localStorage.clear()

    navigate('/auth')
  return (
    <div>LogOut</div>
  )
}

export default LogOut