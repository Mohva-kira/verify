import React from 'react'
import Login from '../components/Login'

const Auth = () => {
  return (
    <div><Login/></div>
  )
}

export default Auth