'use strict';

/**
 * vignette controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::vignette.vignette');
