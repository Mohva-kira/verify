'use strict';

/**
 * vignette router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::vignette.vignette');
